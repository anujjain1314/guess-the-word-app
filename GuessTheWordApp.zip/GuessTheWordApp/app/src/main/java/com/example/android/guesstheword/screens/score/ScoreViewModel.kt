package com.example.android.guesstheword.screens.score

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ScoreViewModel(finalScore: Int) : ViewModel() {

    private val mScore = MutableLiveData<Int>()
    val score : LiveData<Int> get() = mScore


    private val mEventPlayAgain = MutableLiveData<Boolean>()
    val eventPlayAgain : LiveData<Boolean> get() = mEventPlayAgain

    init {
        Log.i("ScoreViewModel", "Final score is $finalScore")
        mScore.value = finalScore
    }

    fun onPlayAgain() {
        mEventPlayAgain.value = true
    }
    fun onPlayAgainComplete() {
        mEventPlayAgain.value = false
    }
}